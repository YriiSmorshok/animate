//
//  ViewController.swift
//  Smorshok
//
//  Created by Сморщок Юрий Сергеевич on 3/3/2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

